# Elite Gaming Hub — Vercel deployment package

This package keeps the existing Elite Gaming Hub pages, admin dashboard, customer booking lookup, pricing/capacity controls, and WhatsApp Cloud API notification logic.

## Before deploying

This is a Vercel serverless project. Do not use `data.json` as live storage: Vercel function files are not persistent. This version stores application state in a Supabase Postgres row and uses a version check to reject simultaneous conflicting writes rather than silently overwriting newer data.

### 1. Create the Supabase database

1. Create a project at https://supabase.com/dashboard.
2. Open **SQL Editor**.
3. Paste and run `supabase-schema.sql`.
4. In **Project Settings → API**, copy the Project URL and the `service_role` key. Keep the service-role key private.

### 2. Deploy to Vercel

1. Upload this folder to a GitHub repository (recommended), or import the repository directly at https://vercel.com/new.
2. Select the repository and deploy. Vercel detects `api/[...path].js` as the serverless API function and serves the website files from `public/`.
3. In **Vercel → Project → Settings → Environment Variables**, add:
   - `SUPABASE_URL` — Supabase Project URL
   - `SUPABASE_SERVICE_ROLE_KEY` — Supabase service-role key (server-side only)
   - `ADMIN_PASSWORD` — a long, unique admin password
   - `WHATSAPP_TOKEN` — Meta WhatsApp Cloud API access token
   - `WHATSAPP_PHONE_NUMBER_ID` — Meta phone number ID
   - `WHATSAPP_API_VERSION` — e.g. `v23.0`
   - `WHATSAPP_TEMPLATE_NAME` — optional approved template name
   - `WHATSAPP_TEMPLATE_LANGUAGE` — template language, e.g. `en_US`
4. Redeploy after setting environment variables.

Never add secrets to HTML/JS files, GitHub, or chat. Do not use the Supabase service-role key in any `NEXT_PUBLIC_*` or browser-exposed variable.

## WhatsApp Cloud API

Set up a Meta app with the WhatsApp product, connect/verify the business phone number, and copy its Phone Number ID and a valid access token into Vercel's private environment variables. For business-initiated notifications outside the customer-service window, configure an approved WhatsApp message template and set `WHATSAPP_TEMPLATE_NAME` and `WHATSAPP_TEMPLATE_LANGUAGE` to match the approved template.

The current notifier sends a single body parameter containing the booking message when a template is configured. The approved template must therefore have a compatible body placeholder. If no template is configured, the app attempts a text message; Meta may reject that message when a template is required by WhatsApp policy.

## Admin

The admin login is restricted to `randhejayaprakash@gmail.com` in the existing application code. Set `ADMIN_PASSWORD` in Vercel. Never commit a real password.

## Important operational notes

- The database row stores the app's settings, bookings, availability blocks, logs, and admin sessions. Row-level security is enabled; do not create public read/write policies. The server accesses it with the service-role key.
- The app uses optimistic versioning. If two writes overlap, one may receive a `409 Concurrent update detected` response and should be retried. This avoids silent last-write-wins data loss, but is a small-business starter architecture rather than a high-volume booking engine. For heavy traffic, move bookings/settings/sessions into separate relational tables and enforce slot capacity in a Postgres transaction/RPC.
- Verify business phone number, console capacity, prices, opening hours, and WhatsApp recipient number in the admin settings before going live.
- Payments remain offline/cash at the counter. No online payment gateway is included.
- This package does not deploy itself or create your Vercel/Supabase/Meta accounts. You must connect those accounts and add their credentials privately.
