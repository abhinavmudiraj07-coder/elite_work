-- Run this once in Supabase Dashboard > SQL Editor.
-- The service-role key is used only by the Vercel server function. Never expose it in browser code.
create table if not exists public.app_state (
  id integer primary key check (id = 1),
  version bigint not null default 0,
  state jsonb not null
);

alter table public.app_state enable row level security;
-- Do not add public anon/authenticated policies. Server access uses the service-role key.
