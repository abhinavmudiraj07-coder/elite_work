ELITE GAMING HUB — VERCEL PACKAGE

Start with README-VERCEL.md for the Vercel + Supabase deployment instructions.
Run supabase-schema.sql once in the Supabase SQL Editor before the first deployment.

The original static pages are in public/. The serverless API entry point is api/[...path].js.
Do not use data.json as production storage. Set Supabase and admin/WhatsApp secrets in Vercel Environment Variables.
